package colab.common.remote.exception;


public class UserDoesNotExistException extends AuthenticationException {

}
