package colab.common.naming;

public class InvalidCommunityNameException extends InvalidNameException {

}
