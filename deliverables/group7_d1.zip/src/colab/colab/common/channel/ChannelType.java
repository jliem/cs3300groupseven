package colab.common.channel;

public enum ChannelType {
  CHAT{public String toString(){return "Chat";}},
  WHITE_BOARD{public String toString(){return "White Board";}},
  DOCUMENT{public String toString(){return "Document";}}
}