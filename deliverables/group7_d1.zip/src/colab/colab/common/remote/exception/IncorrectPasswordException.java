package colab.common.remote.exception;


public class IncorrectPasswordException extends AuthenticationException {

}
