package colab.common.naming;

public class InvalidUserNameException extends InvalidNameException {

}
