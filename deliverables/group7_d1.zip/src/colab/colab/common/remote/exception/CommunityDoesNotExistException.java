package colab.common.remote.exception;

public class CommunityDoesNotExistException
        extends AuthenticationException {

}
