package colab.common.identity;

import junit.framework.TestCase;


/**
 * Test cases for {@link IdentitySet}.
 */
public final class IdentitySetTester extends TestCase {

    /**
     * Adds several Users to an IdentitySet and retrieves one of them.
     */
    public void testUserSet() {
/*
        IdentitySet<UserName, User> set = new IdentitySet<UserName, User>();

        User johannes = new User("Johannes", "pass1");
        set.add(johannes);

        User pamela = new User("Pamela", "pass2");
        set.add(pamela);

        User matt = new User("Matthew", "pass3");
        set.add(matt);

        User chris = new User("Chris", "pass4");
        set.add(chris);

        super.assertEquals(set.get(new UserName("Matthew")), matt);
*/
    }

}
