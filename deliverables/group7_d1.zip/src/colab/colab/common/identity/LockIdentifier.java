package colab.common.identity;

/**
 * Implementation of the LockIdentifier interface indicates
 * that a class can be used as the subject of a lock action.
 */
public interface LockIdentifier {

}
